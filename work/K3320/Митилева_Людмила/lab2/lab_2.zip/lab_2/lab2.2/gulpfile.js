var gulp = require('gulp');

gulp.task('mytask', function () {
    console.log('Hello, Luda. I\'m your first task!');
})
