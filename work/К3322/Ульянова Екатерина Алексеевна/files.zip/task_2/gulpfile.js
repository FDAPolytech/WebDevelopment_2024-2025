const gulp = require('gulp');

gulp.task('test_task', function(done) {
    console.log('Done!');
    done();
});