const gulp = require("gulp");
const browserSync = require("browser-sync").create();

const paths = {
  html: "src/*.html",
  css: "src/css/*.css",
  js: "src/js/*.js",
};

function serve() {
  browserSync.init({
    server: {
      baseDir: "src",
    },
  });

  gulp.watch(paths.html).on("change", browserSync.reload);
  gulp.watch(paths.css).on("change", browserSync.reload);
  gulp.watch(paths.js).on("change", browserSync.reload);
}

exports.default = serve;
