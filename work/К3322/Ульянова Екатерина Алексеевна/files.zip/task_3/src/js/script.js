const siteList = document.getElementById("site-list");
const webViewer = document.getElementById("web-viewer");
const settingsForm = document.getElementById("settings-form");
const pageUrlInput = document.getElementById("page-url");
const intervalInput = document.getElementById("interval");

let sites = [];
let currentIndex = 0;
let intervalTime = 5000;
let intervalId = null;

function updateSiteList() {
  siteList.innerHTML = "";
  sites.forEach((site, index) => {
    const li = document.createElement("li");
    li.textContent = `${index + 1}. ${site}`;
    siteList.appendChild(li);
  });
}


function startRotation() {
  if (intervalId) {
    clearInterval(intervalId);
  }
  if (sites.length > 0) {
    webViewer.src = sites[currentIndex];
    intervalId = setInterval(() => {
      currentIndex = (currentIndex + 1) % sites.length;
      webViewer.src = sites[currentIndex];
    }, intervalTime);
  }
}


settingsForm.addEventListener("submit", (e) => {
  e.preventDefault();

  const pageUrl = pageUrlInput.value.trim();
  const interval = parseInt(intervalInput.value.trim(), 10);

  if (pageUrl && interval >= 1000) {
    sites.push(pageUrl); // Добавляем URL в массив
    intervalTime = interval; // Устанавливаем новый интервал
    pageUrlInput.value = ""; // Сбрасываем поле ввода URL
    intervalInput.value = ""; // Сбрасываем поле ввода интервала
    updateSiteList(); // Обновляем список сайтов
    startRotation(); // Перезапускаем ротацию
  } else {
    alert("Please enter a valid URL and interval (minimum 1000 ms).");
  }
});

// Инициализация
updateSiteList();
